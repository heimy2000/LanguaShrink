import re
import os
import openai
from openai import OpenAI
import time
import tiktoken
import logging

compress_prompt ="""以下是一套用于简化文本的规则，旨在帮助用户根据不同的阅读和理解需求选择合适的简化级别。
基本规则：
删除非关键信息：
如果句子中有两个逗号或破折号，考虑删除它们之间的部分，除非该部分包含关键信息。
删除所有非关键的形容词和副词。
简化从句和修饰语：
如果存在只有一个逗号后接定语从句，考虑删除该从句。
删除所有非关键的定语、状语和同位语。
高级规则：
处理复杂关系句：
转折关系：保留转折后的主要信息。
让步关系：根据上下文重要性保留关键部分。
原因关系：保留原因说明。
结果关系：突出导致结果的因素。
条件关系：保留条件说明。
递进关系：强调递进部分的信息。
比较关系：突出比较的主要内容。
并列关系：保持内容的平等处理。
可选性保留：
特别注意保留人名、地名、专有名词等重要信息。
简化级别选择：
极轻简化：仅去除冗余的修饰词。
轻度简化：应用基本的逗号和从句删除规则。
中度简化：应用所有基本规则。
深度简化：应用基本和高级规则，保留关键句意。
极深简化：极端减少细节，仅保留句子的主体（主谓宾）。
示例：
原句："The economy, despite facing numerous challenges from external factors such as global market fluctuations and geopolitical tensions, continues to grow."
极深简化后："The economy continues to grow."
深度简化后："The economy grows despite challenges."
中度简化后："The economy grows despite external challenges."
轻度简化后："The economy, despite challenges, continues to grow."
极轻简化后："The economy, despite facing numerous challenges, continues to grow.
请使用深度简化级别压缩，不要有和文本无关内容输出
"""


def num_tokens_from_messages(messages, model="gpt-3.5-turbo-0613"):
    """Return the number of tokens used by a list of messages."""
    try:
        encoding = tiktoken.encoding_for_model(model)
    except KeyError:
        print("Warning: model not found. Using cl100k_base encoding.")
        encoding = tiktoken.get_encoding("cl100k_base")
    if model in {
        "gpt-3.5-turbo-0613",
        "gpt-3.5-turbo-16k-0613",
        "gpt-4-0314",
        "gpt-4-32k-0314",
        "gpt-4-0613",
        "gpt-4-32k-0613",
    }:
        tokens_per_message = 3
        tokens_per_name = 1
    elif model == "gpt-3.5-turbo-0301":
        tokens_per_message = 4  # every message follows <|start|>{role/name}\n{content}<|end|>\n
        tokens_per_name = -1  # if there's a name, the role is omitted
    elif "gpt-3.5-turbo" in model:
        print("Warning: gpt-3.5-turbo may update over time. Returning num tokens assuming gpt-3.5-turboc.")
        return num_tokens_from_messages(messages, model="gpt-3.5-turbo-0613")
    elif "gpt-4" in model:
        print("Warning: gpt-4 may update over time. Returning num tokens assuming gpt-4-0613.")
        return num_tokens_from_messages(messages, model="gpt-4-0613")
    else:
        raise NotImplementedError(
            f"""num_tokens_from_messages() is not implemented for model {model}. See https://github.com/openai/openai-python/blob/main/chatml.md for information on how messages are converted to tokens."""
        )
    num_tokens = 0
    for message in messages:
        num_tokens += tokens_per_message
        for key, value in message.items():
            num_tokens += len(encoding.encode(value))
            if key == "name":
                num_tokens += tokens_per_name
    num_tokens += 3  # every reply is primed with <|start|>assistant<|message|>
    return num_tokens

def setup_logger(name, log_file, level=logging.INFO):
    """Function to set up a logger with the specified name and log file."""
    handler = logging.FileHandler(log_file)
    formatter = logging.Formatter('%(asctime)s:%(levelname)s:%(message)s')
    handler.setFormatter(formatter)
    logger = logging.getLogger(name)
    logger.setLevel(level)
    logger.addHandler(handler)
    return logger

if __name__ == "__main__":
    output_folder = 'compress_qw_jijian'
    log_directory = 'logs_compress_qw_jijian'
    os.makedirs(log_directory, exist_ok=True)  # Ensure the log directory exists
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    CHUNK_SIZE = 1024  # Make sure to define CHUNK_SIZE if it's not defined elsewhere in your code
    total_tokens = 0
    total_time = 0
    num_files = 0

    # Setup client here based on your system configuration for API access
    client = OpenAI(
        base_url='http://localhost:11434/v1',
        api_key='ollama',
    )
    for filename in os.listdir('split'):
        if filename.endswith('.txt'):
            num_files += 1
            file_path = os.path.join('split', filename)
            log_path = os.path.join(log_directory, f"{os.path.splitext(filename)[0]}_log.log")
            logger = setup_logger(name=filename, log_file=log_path)

            with open(file_path, 'r', encoding='utf-8') as file:
                content = file.read()

            model = 'gpt-4-32k-0314'
            example_messages = [
                {
                    "role": "user",
                    "content": content,
                },
            ]
            start_time = time.time()
            compressed_content = ""
            chunks = [content[i:i + CHUNK_SIZE] for i in range(0, len(content), CHUNK_SIZE)]
            compressed_chunks = []

            for chunk in chunks:
                try:
                    summary_response = client.chat.completions.create(
                        model="qwen:0.5b-chat",
                        messages=[
                            {"role": "system", "content": compress_prompt},
                            {"role": "user", "content": chunk}
                        ]
                    )
                    compressed_chunks.append(summary_response.choices[0].message.content)
                except Exception as e:
                    logger.error(f"Error during compression: {e}")

            end_time = time.time()
            processing_time = end_time - start_time
            total_time += processing_time

            compressed_content = "".join(compressed_chunks)
            compressed_content = re.sub(r'\n+', ' ', compressed_content)
            compressed_content = re.sub(r'\s+', ' ', compressed_content)
            example_messages = [
                {
                    "role": "user",
                    "content": compressed_content,
                },
            ]
            tokens = num_tokens_from_messages(example_messages, model)
            total_tokens += tokens
            logger.info(f"Processing time for {filename}: {processing_time} seconds")
            logger.info(f"Number of tokens for {filename}: {tokens}")

            output_file_path = os.path.join(output_folder, f"{os.path.splitext(filename)[0]}.txt")
            with open(output_file_path, 'w', encoding='utf-8') as file:
                file.write(compressed_content)

    # Log average values
    if num_files > 0:
        average_tokens = total_tokens / num_files
        average_time = total_time / num_files
        with open(os.path.join(log_directory, 'average_metrics.log'), 'w') as log_file:
            log_file.write(f"Average number of tokens: {average_tokens}\n")
            log_file.write(f"Average processing time: {average_time} seconds\n")